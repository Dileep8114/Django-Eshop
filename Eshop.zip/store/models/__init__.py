from .product import Product
from .category import Category
from .customer import Customer
from .color import Color
from .orders import Orders